(() => {
  "use strict";

  // The bundled factory only starts this worker for a fixed list of extension
  // IDs. An unpacked installation gets a new ID, leaving downloads queued
  // forever. Keep one explicit worker alive for the lifetime of this page.
  if (globalThis.__phoenixVideoDownloaderWorker) {
    return;
  }

  const workerUrl = chrome.runtime.getURL("/download_worker/main.js");
  const worker = new Worker(workerUrl, { type: "module" });

  worker.addEventListener("error", (event) => {
    console.error(
      "Phoenix Video Downloader: the internal download worker failed to start.",
      event.message || event
    );
  });

  globalThis.__phoenixVideoDownloaderWorker = worker;
})();
